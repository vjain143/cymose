package com.splunk.examples.testupdate;

/**
 * Created with IntelliJ IDEA.
 * User: fross
 * Date: 11/4/13
 * Time: 1:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class Program {
}
